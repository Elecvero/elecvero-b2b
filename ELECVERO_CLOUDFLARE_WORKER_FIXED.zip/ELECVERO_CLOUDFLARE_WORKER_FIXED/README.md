# ELECVERO B2B — Cloudflare Worker Fixed Build

Cloudflare Worker + static ELECVERO B2B catalogue + D1-ready order API.

## Routes
- GET `/api/health`
- GET `/api/products`
- POST `/api/quote`
- POST `/api/orders` (requires D1 binding)

## Deployment
The Worker entry point is `src/index.js`. Static files are served from `public/` using the Cloudflare Workers Assets binding.

The first deployment intentionally does not bind D1, so the Worker can go live without a database-ID mismatch. After deployment, bind the existing `elecvero-db` D1 database in Cloudflare and apply `migrations/0001_initial.sql`.
