# ELECVERO — Website Requirements

## Core
- Responsive desktop/mobile B2B storefront
- Search by product name/category/SKU
- Category navigation
- Product cards and detail modal
- 481 catalogue products
- 29 product categories
- Pack quantity/MOQ visibility
- Customer-facing ELECVERO SKUs
- Local persistent basket
- Basket-value discount engine
- Business/dealer account enquiry
- Order request capture into D1
- WhatsApp ordering
- Quote/order API
- Policies: terms, privacy, shipping & returns

## Future integrations
- Razorpay server-side payment orders
- Zoho Inventory stock/fulfilment
- Zoho Books invoices/GST/P&L
- Shipping provider
- Dealer login/authentication
- Live stock
- Admin/product management
