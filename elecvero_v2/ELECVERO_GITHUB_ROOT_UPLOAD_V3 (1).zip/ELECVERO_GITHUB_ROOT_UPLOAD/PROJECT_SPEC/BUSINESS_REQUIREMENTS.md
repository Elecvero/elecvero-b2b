# ELECVERO — Business Requirements

- Customer-facing brand: ELECVERO
- Domain: https://elecvero.in
- Legal structure: proprietorship; proprietor is user's mother
- Proposed trade name: ELECVERO ENTERPRISES
- State: Maharashtra, India
- Business model: B2B wholesale/trading + online ordering
- Contact: +91 72086 83604
- Preferred email: support@elecvero.in
- Positioning: electrical accessories for retailers, wholesalers, distributors, contractors and project buyers
- Core promise: “Stock smarter. Sell faster.”
- Brand ethos: “Built for the trade. Ready for scale.”
- Website must feel like a professional B2B commerce portal, not a PDF/catalogue or spreadsheet.
- Customer-facing old supplier D-xxxx codes must never be shown.
- Customer-facing product IDs are ELECVERO EV-XXX-### SKUs.
- The supplied catalogue is the source of truth. Do not invent unsupported product specifications, MRP or pack quantities.
