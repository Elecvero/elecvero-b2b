# ELECVERO — Deployment

Target platform: Cloudflare Workers + D1.

1. Create/use D1 database `elecvero-db`.
2. Copy the database ID into `wrangler.toml`.
3. From this project folder:
   `npx wrangler login`
4. Apply the migration:
   `npx wrangler d1 migrations apply elecvero-db --remote`
5. Deploy:
   `npx wrangler deploy`
6. Test:
   `/api/health`
   `/api/products`
   `/api/categories`
7. Add `elecvero.in` as the production custom domain/route only after the API health check and catalogue test pass.

Do not delete the previous Cloudflare project until this version has passed QA.
