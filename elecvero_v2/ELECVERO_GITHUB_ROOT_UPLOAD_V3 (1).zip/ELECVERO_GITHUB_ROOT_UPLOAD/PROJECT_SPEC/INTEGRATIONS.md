# ELECVERO — Integration Roadmap

Architecture:
Frontend → Cloudflare Worker → D1
                     ↘ future Zoho Inventory
                     ↘ future Zoho Books
                     ↘ future Razorpay
                     ↘ future shipping provider

Current scope:
- Cloudflare Worker API
- Cloudflare D1
- Catalogue data
- Account requests
- Order requests
- Basket/quote calculation
- WhatsApp

Not claimed live until credentials/accounts are connected:
- Razorpay
- Zoho Inventory
- Zoho Books
- GST registration/billing
- Shipping partner account
