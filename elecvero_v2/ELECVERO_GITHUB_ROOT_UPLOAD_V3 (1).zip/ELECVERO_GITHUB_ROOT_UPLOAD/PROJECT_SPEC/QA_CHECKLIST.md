# ELECVERO — QA Checklist

Before production:
- [ ] `/api/health` returns ok:true and database:true
- [ ] `/api/health` product_count = 481
- [ ] `/api/products` returns all 481 products
- [ ] 29 categories render
- [ ] Search works
- [ ] Category filters work
- [ ] All customer-facing SKUs begin with EV-
- [ ] No D-xxxx supplier code appears in public JSON/API response
- [ ] No D-xxxx code is displayed in customer UI
- [ ] Images load for all mapped products
- [ ] Products without source images use placeholder
- [ ] Pack-aware basket math works
- [ ] 5/7.5/10/12.5/15% tiers work at exact thresholds
- [ ] Account request persists to D1
- [ ] Order request persists to D1
- [ ] WhatsApp order text works
- [ ] Mobile layout tested
- [ ] Terms/privacy/shipping pages open
- [ ] Domain switched only after all above pass
