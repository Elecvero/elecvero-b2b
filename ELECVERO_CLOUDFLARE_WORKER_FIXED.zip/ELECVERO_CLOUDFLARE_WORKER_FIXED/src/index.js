const DISCOUNT_TIERS = [
  { min: 0, max: 9999.99, rate: 0.05 },
  { min: 10000, max: 24999.99, rate: 0.075 },
  { min: 25000, max: 49999.99, rate: 0.10 },
  { min: 50000, max: 99999.99, rate: 0.125 },
  { min: 100000, max: Infinity, rate: 0.15 },
];

function discountRate(subtotal) {
  return (DISCOUNT_TIERS.find(t => subtotal >= t.min && subtotal <= t.max) || DISCOUNT_TIERS[0]).rate;
}

function json(data, status = 200) {
  return new Response(JSON.stringify(data), {
    status,
    headers: { 'content-type': 'application/json; charset=UTF-8', 'cache-control': 'no-store' }
  });
}

async function getProducts(env, request) {
  const url = new URL('/assets/products.json', request.url);
  const response = await env.ASSETS.fetch(new Request(url));
  if (!response.ok) throw new Error('Product catalogue unavailable');
  return response.json();
}

async function api(request, env) {
  const url = new URL(request.url);

  if (url.pathname === '/api/health' && request.method === 'GET') {
    return json({ ok: true, service: 'ELECVERO B2B Worker', version: '1.0.0', d1: Boolean(env.DB) });
  }

  if (url.pathname === '/api/products' && request.method === 'GET') {
    const products = await getProducts(env, request);
    return json({ count: products.length, products });
  }

  if (url.pathname === '/api/quote' && request.method === 'POST') {
    const body = await request.json().catch(() => null);
    if (!body || !Array.isArray(body.items)) return json({ error: 'items array is required' }, 400);
    const subtotal = body.items.reduce((sum, item) => sum + Number(item.unit_price || 0) * Number(item.qty || 0), 0);
    const rate = discountRate(subtotal);
    return json({
      subtotal,
      discount_rate: rate,
      discount: subtotal * rate,
      total: subtotal * (1 - rate),
      currency: 'INR'
    });
  }

  if (url.pathname === '/api/orders' && request.method === 'POST') {
    if (!env.DB) return json({ error: 'Order database is not connected yet', code: 'D1_NOT_BOUND' }, 503);
    const body = await request.json().catch(() => null);
    if (!body || !Array.isArray(body.items) || body.items.length === 0) return json({ error: 'items are required' }, 400);
    const orderId = crypto.randomUUID();
    const now = new Date().toISOString();
    const subtotal = body.items.reduce((sum, item) => sum + Number(item.unit_price || 0) * Number(item.qty || 0), 0);
    const rate = discountRate(subtotal);
    const total = subtotal * (1 - rate);
    await env.DB.prepare(`INSERT INTO orders (id, customer_name, customer_phone, customer_email, subtotal, discount_rate, total, status, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`)
      .bind(orderId, body.customer_name || null, body.customer_phone || null, body.customer_email || null, subtotal, rate, total, 'received', now).run();
    for (const item of body.items) {
      await env.DB.prepare(`INSERT INTO order_items (order_id, sku, product_name, qty, unit_price, line_total) VALUES (?, ?, ?, ?, ?, ?)`)
        .bind(orderId, item.sku || null, item.product_name || null, Number(item.qty || 0), Number(item.unit_price || 0), Number(item.unit_price || 0) * Number(item.qty || 0)).run();
    }
    return json({ ok: true, order_id: orderId, subtotal, discount_rate: rate, total, status: 'received' }, 201);
  }

  return null;
}

export default {
  async fetch(request, env, ctx) {
    try {
      if (new URL(request.url).pathname.startsWith('/api/')) {
        const result = await api(request, env);
        if (result) return result;
      }
      return env.ASSETS.fetch(request);
    } catch (error) {
      return json({ error: error.message || 'Internal error' }, 500);
    }
  }
};
