# ELECVERO — Pricing Rules

Basket discount tiers:
- ₹0–₹9,999: 5%
- ₹10,000–₹24,999: 7.5%
- ₹25,000–₹49,999: 10%
- ₹50,000–₹99,999: 12.5%
- ₹1,00,000+: 15%

The current site calculates basket discount against catalogue list value before final GST/freight/payment confirmation.

Pack-aware ordering:
- If a product has a numeric pack quantity, basket quantity represents packs.
- Line value = catalogue MRP per unit × pack quantity × number of packs.
- If pack quantity is not supplied, the site treats the order quantity as one unit for calculation and displays that pack quantity is not specified.
- Products with no catalogue MRP are quote-only and are not added to priced baskets.
